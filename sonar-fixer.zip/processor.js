var rp = require('request-promise');
var async = require("async");
var fs = require("fs");

var processor = {};



processor.removeCommentedCode = function(req, res) {
    var data = {
        componentRoots: "ELR05_X3:ELR05_X3",
        rules: "javascript:CommentedCode",
        resolved: false
    };
    var options = {
        uri: 'http://192.168.2.27:9000/api/issues/search',
        qs: data,
        headers: {
            'User-Agent': 'Request-Promise'
        },
        json: true
    };
    rp(options)
        .then(function(parsedBody) {
            console.log("Call succeeded...");
            // res.json({all:parsedBody, componentCount: parsedBody.components.length, issueCount: parsedBody.issues.length});
            async.waterfall([
                function(sortCb) {
                    var sortedArr = parsedBody.components.sort(function(a, b) {
                        return a.id - b.id;
                    });
                    parsedBody.components = sortedArr;
                    sortCb(null, parsedBody);
                },
                function(sortedIssues, componentWiseCb) {
                    var componentArr = sortedIssues.components.filter(function(comp) {
                        return comp.qualifier === "FIL";
                    });

                    var compIssueArr = [];

                    for (var i = 0; i < componentArr.length; i++) {
                        var component = componentArr[i];
                        var componentIssues = sortedIssues.issues.filter(function(issue) {
                            return issue.componentId === component.id;
                        });
                        // componentIssues = componentIssues.sort();
                        compIssueArr.push({
                            componentId: component.id,
                            componentKey: component.key,
                            componentPath: component.path,
                            issues: componentIssues
                        });
                    }

                    componentWiseCb(null, compIssueArr);

                },
                function(compIssueArr, createFileCb) {
                    var processedFiles = [];
                    var tempAr = [compIssueArr[1]];
                    for (var i = 0; i < compIssueArr.length; i++) {
                      console.log(compIssueArr[i].componentKey);
                    }
                    async.each(compIssueArr, function(compIssue, compIssueCb) {
                        var fileData = {
                            resource: compIssue.componentKey
                        };
                        var fileOpts = {
                            uri: 'http://192.168.2.27:9000/api/sources',
                            qs: fileData,
                            headers: {
                                'User-Agent': 'Request-Promise'
                            },
                            json: true
                        };

                        var fileStr = '';

                        rp(fileOpts)
                            .then(function(fileContents) {
                                var multilineFlag = false;
                                var skip = false;
                                var fileContentsJson = fileContents[0];
                                for (var lineKey in fileContentsJson) {
                                    if (fileContentsJson.hasOwnProperty(lineKey)) {
                                        var lineStr = fileContentsJson[lineKey];
                                        if (/\/\//g.test(lineStr)) {
                                            var idx = lineStr.indexOf("//");
                                            if (idx > -1) {
                                                if (idx === 0) {
                                                    skip = true;
                                                } else {
                                                    lineStr = lineStr.replace(lineStr.substr(idx), '');
                                                    skip = false;
                                                }
                                            }
                                        } else if (/\/\*/g.test(lineStr) || multilineFlag) {
                                            multilineFlag = true;
                                            var idx = lineStr.indexOf("/*");
                                            if (idx === 0) {
                                                skip = true;
                                            } else {
                                                lineStr = lineStr.replace(lineStr.substr(idx), '');
                                                skip = false;
                                            }

                                            if (lineStr.indexOf("*/")) {
                                                multilineFlag = false;
                                            }
                                        }

                                        if (skip) {
                                            continue;
                                        } else {
                                            fileStr += ('\n' + lineStr);
                                        }
                                    }
                                }
                                processedFiles.push({
                                  file: compIssue.componentKey,
                                  fileStr: fileStr
                                });
                                compIssueCb();
                            })
                            .catch(function(err) {
                                console.log("Call failed...", err);
                                compIssueCb(err);
                            });

                    }, function(err) {
                        // if any of the file processing produced an error, err would equal that error
                        if (err) {
                            // One of the iterations produced an error.
                            // All processing will now stop.
                            console.log('A file failed to process');
                        } else {
                            createFileCb(null, processedFiles);
                        }
                    });
                }
            ], function(err, results) {
                //res.json(results);
                for (var i = 0; i < results.length; i++) {
                  var filePath = results[i].file;
                  var fileTxt = results[i].fileStr;

//                  fs.writeFile(__dirname + '\\' + filePath, fileTxt, function(err) {
//                      if(err) {
//                          return console.log(err);
//                      }
//
//                      console.log("The file was saved!");
//                  });
                }
                res.set({"Content-Disposition":"attachment; filename=annotations.js"});
                res.send(results[0].fileStr);
            });


        })
        .catch(function(err) {
            console.log("Call failed...", err);
            res.end(JSON.stringify(err));
        });
};

module.exports = processor;
